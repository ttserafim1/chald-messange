# Messenger
Мессенджер написанный на PHP / JS / HTML / CSS с использованием библиотек Bootstrap и JQuery
Предусмотрена работа с модулем MySQLi и самим MySQL

Стандартный вид мессенджера:

![image](https://github.com/Smeruxa/Messenger/assets/57842015/a5127034-43f4-4e93-a613-d38c5f69774d)

Список друзей:

![image](https://github.com/Smeruxa/Messenger/assets/57842015/a3bd1793-04b8-4812-8e9e-9e6c24ffb80d)

Главная страница:

![image](https://github.com/Smeruxa/Messenger/assets/57842015/0741e850-ac3d-4760-b728-707b333b2487)
