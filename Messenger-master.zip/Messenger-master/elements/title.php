<div class="container-fluid bg-black">
    <div class="row">
        <div class="col-md-2">
            <h2 class="h2 text-white">Thrower</h2>
        </div>
    </div>
</div>